"""Offline SHA256 verification; does not download data, trade, or run backtests."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[2]
manifest=json.loads((root/'HANDOFF_MANIFEST.json').read_text())
failed=[]
for entry in manifest['files']:
 p=root/entry['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=entry['sha256']:failed.append(entry['path'])
if failed:raise SystemExit('FAILED: '+', '.join(failed))
print('PASS',len(manifest['files']),'files; data exclusions and Git status are documented separately')
