from pathlib import Path
import csv,json,hashlib,zipfile,platform,sys
from importlib import metadata
ROOT=Path('/workspace/btc-eth-backtest');OUT=ROOT/'handoff/astra_20261114'
env={'python':sys.version,'python_executable':sys.executable,'platform':platform.platform(),'packages':{}}
for name in ('numpy','pandas','pyarrow','requests','openpyxl','tzdata'):
 try:env['packages'][name]=metadata.version(name)
 except metadata.PackageNotFoundError:env['packages'][name]='not installed in this interpreter'
(OUT/'environment.json').write_text(json.dumps(env,ensure_ascii=False,indent=2))
rows=json.loads((ROOT/'outputs/adaptive_risk_exit_v2_extended/comparison.json').read_text())
for x in json.loads((ROOT/'outputs/adaptive_risk_exit_v2/comparison.json').read_text())['rows']:
 if x['version']=='CONTROL':continue
 if x['version']=='ADAPTIVE_V2':
  old=next(z for z in json.loads((ROOT/'outputs/adaptive_risk_exit_v2/comparison.json').read_text())['rows'] if z['year']==x['year'] and z['version']=='CONTROL')
  rows.append(dict(year=x['year'],period='全年',status=x['status'],CONTROL_return_pct=old['return_pct'],CONTROL_drawdown_pct=old['max_drawdown_pct'],CONTROL_opens=old['opens'],DYNAMIC_return_pct=x['return_pct'],DYNAMIC_drawdown_pct=x['max_drawdown_pct'],DYNAMIC_opens=x['opens']))
rows.sort(key=lambda r:r['year']);fields=list(dict.fromkeys(k for r in rows for k in r))
with (OUT/'ANNUAL_RESULTS.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
original=json.loads((ROOT/'outputs/retry_nov9_nov12/source_restore.json').read_text())
files={ROOT/x['path'] for x in original['files']}
files.update(ROOT.glob('work/*.py'));files.update(ROOT.glob('outputs/**/*.py'));files.update(OUT.glob('*'))
selected=['adaptive_risk_exit_v2','adaptive_risk_exit_v2_extended','adaptive_risk_exit','binance_perpetual_raw_execution','nov9_today_simultaneous','cross_asset_entry_audit']
for name in selected:
 for p in (ROOT/'outputs'/name).rglob('*'):
  if p.is_file() and not any(x in ('data','temporary','__pycache__','responses') for x in p.relative_to(ROOT/'outputs'/name).parts) and p.suffix.lower() in ('.json','.csv','.md','.log','.html','.xlsx','.py'):files.add(p)
files.add(ROOT/'outputs/retry_nov9_nov12/source_restore.json');files.add(ROOT/'ASTRA_REVIEW.md')
# Keep provenance manifests outside excluded data directories; no raw candle/tick inputs.
for p in (ROOT/'outputs').rglob('*sources.json'):
 if 'data' not in p.parts and 'responses' not in p.parts and p.stat().st_size<8_000_000:files.add(p)
files={p for p in files if p.is_file() and p.suffix!='.zip'}
manifest=dict(created='2026-11-14',repository='HITGoose/btc-eth-backtest',remote_V2_synchronized=False,original_commit=original['source_commit'],exclusions=['raw tick ZIPs','minute/15m input arrays and market data folders','equity.npy','caches','credentials'],files=[])
for p in sorted(files):manifest['files'].append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
manifest_path=ROOT/'HANDOFF_MANIFEST.json';manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=OUT/'BTC_ETH_ASTRA_HANDOFF_20261114.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(ROOT)))
 z.write(manifest_path,'HANDOFF_MANIFEST.json')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;assert len(z.namelist())==len(files)+1
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,files=len(files)+1,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),corruption_check='PASS'),ensure_ascii=False))
