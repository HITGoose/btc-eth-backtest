from pathlib import Path
import csv,json,hashlib,statistics,sys,datetime,collections,math
R=Path('/workspace/btc-eth-backtest');O=Path(__file__).resolve().parent;OLD=R/'outputs/rebound_annual_zero';YEARS=['2020','2021','2022','2023','2024','2025','2026'];CATS=['DISTANCE_ONLY','VOLUME_NO_RETEST','RETEST_NO_VOLUME','VOLUME_AND_RETEST','UNCONFIRMED'];LABELS=dict(zip(CATS,['仅距离','放量但无回踩','回踩但无放量','放量且回踩','无法确认']))
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(p,rows):
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with p.open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def boolean(v):
 if v is True or v=='True':return True
 if v is False or v=='False':return False
 return None
sources=[];annual_diags={}
for y in YEARS:
 p=OLD/'runs'/y/'ETH/new_signal_diagnostics.csv';rr=read(p);d={}
 for r in rr:
  k=int(r['signal_close_ms']);assert k not in d;d[k]=r
 annual_diags[y]=d;sources.append(dict(path=str(p.relative_to(R)),SHA256=hashlib.sha256(p.read_bytes()).hexdigest(),rebuild_needed=False))
records=[]
def classify(t,d,scope,stage,source):
 vals={k:boolean(d.get(field))if d else None for k,field in [('near_absolute_2pct','near_absolute_2pct'),('volume_breakout','volume_breakout'),('confirmed_retest','retest')]};n,v,r=vals.values();reason=None
 if any(x is None for x in vals.values()):cat='UNCONFIRMED';reason='MISSING_OR_UNRELIABLE_SIGNAL_TIME_BOOLEAN'
 elif v and r:cat='VOLUME_AND_RETEST'
 elif v:cat='VOLUME_NO_RETEST'
 elif r:cat='RETEST_NO_VOLUME'
 elif n:cat='DISTANCE_ONLY'
 else:cat='UNCONFIRMED';reason='ALL_FALSE_INCONSISTENT_WITH_ADMISSION'
 if d and boolean(d.get('new_signal'))is not True:cat='UNCONFIRMED';reason='DIAGNOSTIC_NOT_ADMITTED_NEW_SIGNAL'
 entry=float(t['entry']);qty=float(t['quantity']);notional=entry*qty;net=float(t['net']);assert notional>0 and math.isfinite(net)
 if t.get('notional')not in [None,'']:assert abs(float(t['notional'])-notional)<1e-6
 records.append(dict(scope=scope,stage=stage,period=t['period']if 'period'in t else 'NOV',asset='ETH',side=t['side'],signal_close_ms=int(t['signal_close_ms']),opened_us=int(t['opened_us']),closed_us=int(t['closed_us']),entry=entry,quantity_initial=qty,initial_notional_USDT=notional,net_USDT=net,net_per1000_initial_notional_USDT=net/notional*1000,**vals,category=cat,category_Chinese=LABELS[cat],unknown_reason=reason,condition_source=source,classification_uses_posthoc_price=False,execution=t.get('execution','RAW_TRADE_SIMULATION'),opened_Beijing=t.get('opened_Beijing'),closed_Beijing=t.get('closed_Beijing')))
trades=read(OLD/'trades.csv')
for t in trades:
 if t['asset']=='ETH'and t['version']=='REBOUND'and t['origin']=='EXTRA':classify(t,annual_diags[t['period']].get(int(t['signal_close_ms'])),'ANNUAL','RAW','saved_new_signal_diagnostics.csv')
assert len(records)==157
# Recent conditions alone are reconstructed with a fresh original state machine;
# no financial replay, account mutation, or live retest state is used.
sys.path.insert(0,str(R/'outputs/rebound_followdown'));from signals import build
cfg=json.loads((OLD/'recent_config.json').read_text());_,_,_,diag,_,_=build('ETH',OLD/'recent_data',cfg['start_ms']//1000,cfg['bar_execution_end_ms']//1000);recent={r['signal_close_ms']:r for r in diag};sources.append(dict(path='outputs/rebound_annual_zero/recent_data/ETH_15m.csv',SHA256=hashlib.sha256((OLD/'recent_data/ETH_15m.csv').read_bytes()).hexdigest(),rebuild_needed=True,rebuild='exact frozen signals.build on cached candles, fresh isolated Probe; no financial replay'))
recent_trades=read(OLD/'recent_trades.csv');dedup=0
for t in recent_trades:
 if t['asset']!='ETH'or t['version']!='REBOUND'or t['origin']!='EXTRA':continue
 if t['execution']=='RAW_TRADE_SIMULATION'and t['stage']!='RAW':dedup+=1;continue
 classify(t,recent.get(int(t['signal_close_ms'])),'RECENT',t['stage'],'reconstructed_original_code_cached_15m')
assert dedup==6
write(O/'trade_attribution.csv',records)
def metrics(rs,scope,stage,period,cat):
 n=len(rs);net=[r['net_USDT']for r in rs];unit=[r['net_per1000_initial_notional_USDT']for r in rs];prof=sorted([x for x in unit if x>0],reverse=True);gp=sum(x for x in net if x>0);ngp=sum(prof)
 return dict(scope=scope,stage=stage,period=period,category=cat,category_Chinese=LABELS.get(cat,cat),trades=n,wins=sum(x>0 for x in net),losses=sum(x<0 for x in net),breakeven=sum(x==0 for x in net),win_rate_pct=100*sum(x>0 for x in net)/n if n else None,net_USDT=sum(net),gross_profit_USDT=gp,gross_loss_USDT=-sum(x for x in net if x<0),max_single_loss_USDT=-min([0.]+net),normalized_mean_USDT=statistics.mean(unit)if n else None,normalized_median_USDT=statistics.median(unit)if n else None,normalized_sum_USDT=sum(unit),normalized_profit_sum_USDT=ngp,normalized_loss_sum_USDT=-sum(x for x in unit if x<0),top1_normalized_positive_profit_share_pct=100*sum(prof[:1])/ngp if ngp else None,top3_normalized_positive_profit_share_pct=100*sum(prof[:3])/ngp if ngp else None,top5_normalized_positive_profit_share_pct=100*sum(prof[:5])/ngp if ngp else None,normalized_net_without_best1_USDT=sum(unit)-sum(prof[:1]),normalized_net_without_best3_USDT=sum(unit)-sum(prof[:3]),not_filtered_account_return=True)
summary=[]
for y in YEARS+['ALL_ANNUAL']:
 rs=[r for r in records if r['scope']=='ANNUAL'and(y=='ALL_ANNUAL'or r['period']==y)]
 for cat in CATS:summary.append(metrics([r for r in rs if r['category']==cat],'ANNUAL','RAW',y,cat))
for stage in ['RAW','OHLC','OLHC']:
 rs=[r for r in records if r['scope']=='RECENT'and r['stage']==stage]
 for cat in CATS:summary.append(metrics([r for r in rs if r['category']==cat],'RECENT',stage,'NOV',cat))
write(O/'category_summary.csv',summary)
comparisons=[]
for y in YEARS+['ALL_ANNUAL']:
 rs=[r for r in records if r['scope']=='ANNUAL'and(y=='ALL_ANNUAL'or r['period']==y)]
 for label,cats in [('DISTANCE_ONLY',['DISTANCE_ONLY']),('VOLUME_OR_RETEST',['VOLUME_NO_RETEST','RETEST_NO_VOLUME','VOLUME_AND_RETEST'])]:comparisons.append(metrics([r for r in rs if r['category']in cats],'ANNUAL','RAW',y,label))
write(O/'retention_comparison.csv',comparisons)
ann=[r for r in records if r['scope']=='ANNUAL'];near=[r for r in ann if r['category']=='DISTANCE_ONLY'];keep=[r for r in ann if r['category']in CATS[1:4]];unknown=[r for r in ann if r['category']=='UNCONFIRMED'];k=metrics(keep,'ANNUAL','RAW','ALL_ANNUAL','VOLUME_OR_RETEST');n=metrics(near,'ANNUAL','RAW','ALL_ANNUAL','DISTANCE_ONLY');positive_years_norm=sum(next(r for r in comparisons if r['period']==y and r['category']=='VOLUME_OR_RETEST')['normalized_sum_USDT']>0 for y in YEARS);positive_years_raw=sum(next(r for r in comparisons if r['period']==y and r['category']=='VOLUME_OR_RETEST')['net_USDT']>0 for y in YEARS);better_years=sum(next(r for r in comparisons if r['period']==y and r['category']=='VOLUME_OR_RETEST')['normalized_mean_USDT']>next(r for r in comparisons if r['period']==y and r['category']=='DISTANCE_ONLY')['normalized_mean_USDT']for y in YEARS)
decision=dict(decision='RUN_ONE_PREDECLARED_F_WITH_LIMITED_SUPPORT',not_claiming_filter_improves_account=True,annual_confirmed=157-len(unknown),annual_unknown=len(unknown),distance_count=len(near),retained_count=len(keep),loss_concentration_note='Distance53.5pct of trades and53.8pct of loss: no material disproportionate loss concentration',support=dict(retained_win_rate_pct=k['win_rate_pct'],distance_win_rate_pct=n['win_rate_pct'],retained_mean_normalized=k['normalized_mean_USDT'],distance_mean_normalized=n['normalized_mean_USDT'],retained_median_normalized=k['normalized_median_USDT'],distance_median_normalized=n['normalized_median_USDT'],retained_positive_normalized_years=positive_years_norm,retained_positive_raw_years=positive_years_raw,retained_relative_better_mean_years=better_years,retained_top1_positive_profit_share_pct=k['top1_normalized_positive_profit_share_pct'],retained_normalized_net_without_best1=k['normalized_net_without_best1_USDT']),limitations=['mean advantage small','relative superiority only3/7 years','removing top3 winning trades reverses normalized net','retest-only and both samples only2 each','removing best normalized year2021 leaves near-zero negative aggregate'],recent_raw_prefix_copies_excluded=dedup,raw_bool_missing_not_false=True)
(O/'attribution_decision.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2));(O/'attribution_sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))
text=['# ETH新增入场类型归因（先归因，未作账户过滤加总）','', '基准133f95967b5789b216406b30117d3703643c7d7a。年度157笔全部由保存的信号时诊断恢复，无缺字段；保存near、volume、retest三个原始布尔。近期仅使用现有缓存和原signals.build独立状态重建，不下载、不重跑账户，不消费原回踩状态。分类不读取事后走势；代码中事后回收标签未参与分类。','', '|类型|成交|赢/亏|净额USDT|总盈利|总亏损|最大单亏|每1000名义均值|每1000名义合计|','|---|---:|---|---:|---:|---:|---:|---:|---:|']
for cat in CATS:
 r=next(x for x in summary if x['period']=='ALL_ANNUAL'and x['category']==cat);fmt=lambda v:'未提供'if v is None else f'{v:.4f}';text.append(f"|{LABELS[cat]}|{r['trades']}|{r['wins']}/{r['losses']}|{r['net_USDT']:.4f}|{r['gross_profit_USDT']:.4f}|{r['gross_loss_USDT']:.4f}|{r['max_single_loss_USDT']:.4f}|{fmt(r['normalized_mean_USDT'])}|{r['normalized_sum_USDT']:.4f}|")
text+=['','单位名义计算：每笔完整net/(初始entry×初始quantity)×1000；包含原V2部分退出，不把剩余数量当初始名义。归一化只作归因，不是一条新的可执行回测。','', '|区间|仅距离笔数|仅距离单位均值|保留笔数|保留单位均值|保留实际净额|','|---|---:|---:|---:|---:|---:|']
for y in YEARS:
 a=next(r for r in comparisons if r['period']==y and r['category']=='DISTANCE_ONLY');b=next(r for r in comparisons if r['period']==y and r['category']=='VOLUME_OR_RETEST');text.append(f"|{y}|{a['trades']}|{a['normalized_mean_USDT']:.4f}|{b['trades']}|{b['normalized_mean_USDT']:.4f}|{b['net_USDT']:.4f}|")
text+=['','## 是否继续','', '有限支持继续一次预先指定的F，但不能据归因宣称改进成功。保留组73笔、40赢33亏，单位均值+1.1316、中位数+9.7639；距离组84笔、39赢45亏，单位均值−0.1764、中位数−14.7285。保留组5/7年单位名义合计为正、4/7年实际净额为正，盈利不只来自单笔：最大盈利仅占单位总盈利6.83%，去掉最大盈利后单位净额仍+32.7974。','', '反面证据同时保留：距离组占53.5%样本、53.8%总亏损，不能称亏损显著集中；保留组单位均值只在3/7年优于距离组，去掉前三大盈利后单位净额转负；回踩相关两类各仅2笔，不能单独得出回踩有效。去掉2021后保留组单位净额约−1.74，优势很薄。','', '因此这里只把胜率、中位数、单位均值及多个正收益年份作为跑一次F的有限依据，不把保留交易加总冒充F的账户收益。下一步仅生成volume OR retest的固定F完整ETH账户；A/E/BTC复用，不加阈值或其他条件。','', '逐年五类统计及盈利集中度见category_summary.csv；原布尔、初始名义及每笔归一化见trade_attribution.csv。近期RAW3笔与OHLC/OLHC各1笔分开，已排除6条重复逐笔前缀，不把两条假设路径当独立样本相加。']
(O/'ATTRIBUTION.md').write_text('\n'.join(text));print('ATTRIBUTED',len(ann),'RECENT',len(records)-len(ann));print(json.dumps(decision,ensure_ascii=False))
if __name__=='__main__':pass
