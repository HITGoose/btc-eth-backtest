from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST_SHA256.json').read_text())
for p,q in m['files'].items():
 f=r/p
 if not f.is_file()or hashlib.sha256(f.read_bytes()).hexdigest()!=q['SHA256']:raise SystemExit('MISSING_OR_CHANGED: '+p)
print('ALL_FILES_SHA256_OK',len(m['files']))
