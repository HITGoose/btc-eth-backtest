"""Offline deterministic matching of saved ledgers, not financial backtesting.
Python3.12 standard library only; never imports the trading worker or calls a market API.
"""
from pathlib import Path
import ast,csv,json,hashlib,sys,argparse

def refuse_network(event,args):
 if event.startswith('socket.')or event in ('subprocess.Popen','os.system'):raise RuntimeError('Offline matcher forbids network/process creation: '+event)
sys.addaudithook(refuse_network)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path);args=p.parse_args();root=args.root.resolve();o=root/'outputs/adaptive_density_control'
 frozen=json.loads((o/'FREEZE.json').read_text());ns=dict(comparison=[],matches=[])
 source=o/'report.py';tree=ast.parse(source.read_text(encoding='utf-8'));want={'trade_key','open_key','reason','attribute','csvwrite'}
 # Use one namespace so the original functions resolve one another exactly.
 ns['json']=json;ns['csv']=csv
 for node in tree.body:
  if isinstance(node,ast.FunctionDef)and node.name in want:exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
 assert want<=set(ns),'Original matching functions missing'
 def location(year,asset,fee,group):
  if year in ['2020','2021','2022']and fee=='ZERO'and group in ['A','B','C']:
   key='ZERO_'+('A'if group=='A'else frozen[group]);stage='train'
  else:key=fee+'_'+group;stage='train_final'if year in ['2020','2021','2022']else'final'
  folder=o/'runs'/stage/year/asset;return folder,key
 def load(folder,key):return json.loads((folder/'results'/(key+'_result.json')).read_text(encoding='utf-8'))
 def accepted(folder,key):return {int(k):v for k,v in json.loads((folder/'signals.json').read_text())['accepted'][key].items()}
 for year in ['2020','2021','2022','2023','2024','2025','2026']:
  for fee in ['ZERO','ASSUMED_005_SIDE']:
   for asset in ['BTC','ETH']:
    fa,ka=location(year,asset,fee,'A');a=load(fa,ka);amap=accepted(fa,ka)
    for group in ['B','C','D']:
     fv,kv=location(year,asset,fee,group);v=load(fv,kv);ns['attribute']('ANNUAL',year,asset,fee,group,a,v,amap,accepted(fv,kv))
 for scene in ['RAW','OHLC','OLHC']:
  for fee in ['ZERO','ASSUMED_005_SIDE']:
   for asset in ['BTC','ETH']:
    folder=o/'recent'/asset;maps=json.loads((folder/('signals_RAW.json'if scene=='RAW'else'signals_BAR.json')).read_text())['accepted'];a=load(folder/scene,fee+'_A');amap={int(k):v for k,v in maps[fee+'_A'].items()}
    for group in ['B','C','D']:
     v=load(folder/scene,fee+'_'+group);ns['attribute']('RECENT_'+scene,'NOV',asset,fee,group,a,v,amap,{int(k):v for k,v in maps[fee+'_'+group].items()})
 output=args.output or root/'reproduced/trade_matching.csv';output=output.resolve();reference=o/'trade_matching.csv'
 if output==reference.resolve():raise RuntimeError('Refusing to overwrite the supplied reference')
 output.parent.mkdir(parents=True,exist_ok=True);ns['csvwrite'](output,ns['matches']);raw=output.read_bytes();expected=reference.read_bytes();check=dict(mode='OFFLINE_MATCHING_FROM_SAVED_LEDGERS_NOT_PRICE_REPLAY',network_forbidden=True,financial_replays=0,rows=len(ns['matches']),SHA256=hashlib.sha256(raw).hexdigest(),reference_SHA256=hashlib.sha256(expected).hexdigest(),byte_identical=raw==expected,output=str(output))
 (output.parent/'verification.json').write_text(json.dumps(check,indent=2));print(json.dumps(check,ensure_ascii=False,indent=2))
 if raw!=expected:raise SystemExit('Mismatch: reference retained; no strategy/backtest was run')
if __name__=='__main__':main()
