# 离线复现交付：A/B/C/D adaptive_density_control

源代码/原结果基准：7a4a9fedaf9d297d85c0fa6279acd2627db2497f。策略源码没有修改，main没有修改。

## 先说明能复现什么

本ZIP能在Python3.12标准库环境下，**从完整保存的单币账本及信号重新按原逻辑生成trade_matching.csv**，不只是复制参考CSV。已在禁止网络、临时路径解压后实际执行并核对SHA256。

**这不是完整原始逐笔行情包，不能声称从K线从头离线重跑金融撮合。** 原金融引擎还需要原始逐笔成交与官方校验，来源记录有3341个日档、约87.99GiB；当前缓存大多已经清理。包内不伪造这些数据、不用K线高低替代。缺失清单RAW_TICKS_REQUIRED.csv有URL/SHA/大小。未下载88GiB来冒充齐全。

## 最简单的离线命令（任意解压路径）

先把ZIP解压，进入btc-eth-backtest目录：

```bash
python offline_reproduce_trade_matching.py
```

Windows可用`py -3.12 offline_reproduce_trade_matching.py`。无需pip、NumPy、pandas或网络。输出reproduced/trade_matching.csv及verification.json；byte_identical应为true。禁止覆盖随包参考结果。此命令只是已有账本后处理，不是价格路径重放，也不能用于验证新策略改动。

## 原完整回测代码入口（随包未修改）

- outputs/adaptive_density_control/signals.py：六线/ER及A/B/C自适应候选、D并集。
- engine.py：原CONTROL出场、3x CORE/1x EXTRA和优先替换；无V2、无反弹续跌。
- worker.py：复利定量、逐笔撮合驱动、断点、2025 S_ALL。
- train_supervisor.py、freeze.py、final_supervisor.py、recent_worker.py：三年训练、冻结、年度和近期。
- report.py：原完整报表及trade_matching匹配逻辑；离线入口直接提取其中原函数，避免导入历史行情加载器。
- work/fit_squeeze_ladder_bot.py、fit_gate_entry_overlay.py、gate_october_regime_entries.py、replay_gate_october_seconds.py等及所有本地Python源码均保留原目录。
- DEPENDENCIES_LOCAL.json列出实际运行导入的45个本地模块，并列出全部随包源文件。

原回测脚本在多处硬编码/workspace/btc-eth-backtest，且需要requirements.txt第三方依赖、全部必要逐笔缓存/官方校验。只安装依赖或者只有本ZIP，**不能声称已具备从头离线金融重放条件**。不要直接运行原main入口：它是另一个entry_crosses版本，不是本轮CONTROL。本次没有重跑七年账户。

## 冻结版本与数据

A：CONTROL，Settings(96,5,.25,uncapped)，最终六线6条同向，pause_transition=True，原ER，0.25%/0.50%。
B：分位数(q_s,q_w)=(.25,.50)，过去2880根不含当前；C：WilderATR96归一化(k_s,k_w)=(1,2)。
D：A的CORE优先＋B的EXTRA，CORE按已实现余额3x，EXTRA1x，单币单仓不叠加资金。各年每币500独立起算；费用ZERO与假设每边.05%，资金费0，退出滑点.02%。

包含实际读取的2020—2026 BTC/ETH 15m CSV和1m NPY（含各自预热），以及匹配表近期部分需要的Nov1起数据。DATA_INVENTORY.json给出每个实际路径、覆盖区间、大小、SHA。2020从2月16日，2026年度仅1—10月；近期不拼接成年收益。2025 S_ALL保持COMPLETED_WITH_DATA_ANOMALY，近期OHLC/OLHC保持假设标签。

包内含原始已保存交易账本、信号、配置、权益曲线、原输出及SHA256清单。不是仅给一份交易CSV后宣称重跑了撮合。

## 验证与限制

verify_manifest.py仅校验文件哈希；offline_reproduce_trade_matching.py仅重算匹配。完整金融引擎从头重跑未验证且缺原始逐笔，不可把字节一致的匹配表验证冒充金融回测验证。
