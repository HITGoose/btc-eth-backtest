from pathlib import Path
from datetime import datetime,timezone,timedelta
import urllib.request,urllib.parse,json,hashlib,csv,concurrent.futures
O=Path(__file__).resolve().parent;RAW=O/'raw';RAW.mkdir(exist_ok=True);TZ=timezone(timedelta(hours=8));BASE='https://www.binance.com/fapi/v1/'
def request(endpoint,params):
 url=BASE+endpoint+('?' +urllib.parse.urlencode(params)if params else '')
 with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept':'application/json','User-Agent':'market-data-download/1.0'}),timeout=35)as f:body=f.read();status=f.status
 now=datetime.now(timezone.utc);name=endpoint+'_'+hashlib.sha256(url.encode()).hexdigest()[:16]+'.json';p=RAW/name;p.write_bytes(body)
 return json.loads(body),dict(url=url,status=status,received_UTC=now.isoformat(),raw_file=str(p.relative_to(O)),SHA256=hashlib.sha256(body).hexdigest())
clock,clock_source=request('time',{});server=int(clock['serverTime']);start=int(datetime(2026,11,9,tzinfo=TZ).timestamp()*1000);end=min(server//900000*900000,int(datetime(2026,11,16,tzinfo=TZ).timestamp()*1000))
fields=['open_time_ms','open_time_UTC','open_time_Beijing','close_time_ms','close_time_UTC','close_time_Beijing','open','high','low','close','volume_base','quote_volume_USDT','trade_count','taker_buy_base','taker_buy_quote_USDT']
def download(asset):
 cursor=start;rows=[];sources=[]
 while cursor<end:
  data,source=request('klines',dict(symbol=asset+'USDT',interval='15m',startTime=cursor,endTime=end-1,limit=1500));assert isinstance(data,list)and data,(asset,data);sources.append(source)
  for r in data:
   t=int(r[0]);ct=int(r[6]);assert cursor<=t<end and ct==t+899999 and ct<server
   assert float(r[3])>0 and float(r[3])<=min(float(r[1]),float(r[4]))<=max(float(r[1]),float(r[4]))<=float(r[2])
   rows.append(dict(open_time_ms=t,open_time_UTC=datetime.fromtimestamp(t/1000,timezone.utc).isoformat(),open_time_Beijing=datetime.fromtimestamp(t/1000,TZ).isoformat(),close_time_ms=ct,close_time_UTC=datetime.fromtimestamp(ct/1000,timezone.utc).isoformat(timespec='milliseconds'),close_time_Beijing=datetime.fromtimestamp(ct/1000,TZ).isoformat(timespec='milliseconds'),open=r[1],high=r[2],low=r[3],close=r[4],volume_base=r[5],quote_volume_USDT=r[7],trade_count=int(r[8]),taker_buy_base=r[9],taker_buy_quote_USDT=r[10]))
  cursor=int(data[-1][0])+900000
 assert [r['open_time_ms']for r in rows]==list(range(start,end,900000)),(asset,'gaps or duplicates')
 file=O/f'{asset}USDT_15m_20261109_20261115.csv'
 with file.open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 daily=[]
 for day in sorted({r['open_time_Beijing'][:10]for r in rows}):
  v=[r for r in rows if r['open_time_Beijing'].startswith(day)];daily.append(dict(date_Beijing=day,candles=len(v),complete_day=len(v)==96,open=v[0]['open'],high=str(max(float(x['high'])for x in v)),low=str(min(float(x['low'])for x in v)),close=v[-1]['close'],last_bar_open_Beijing=v[-1]['open_time_Beijing']))
 return dict(asset=asset+'USDT',market='BINANCE_USDT_PERPETUAL',interval='15m',candles=len(rows),expected_candles=(end-start)//900000,missing=0,duplicates=0,only_closed=True,start_Beijing=rows[0]['open_time_Beijing'],last_bar_open_Beijing=rows[-1]['open_time_Beijing'],exclusive_end_Beijing=datetime.fromtimestamp(end/1000,TZ).isoformat(),csv=str(file.name),SHA256=hashlib.sha256(file.read_bytes()).hexdigest(),sources=sources,daily=daily)
results=list(concurrent.futures.ThreadPoolExecutor(max_workers=2).map(download,['BTC','ETH']));manifest=dict(acquired_UTC=datetime.now(timezone.utc).isoformat(),server_time_ms=server,server_time_Beijing=datetime.fromtimestamp(server/1000,TZ).isoformat(),clock_source=clock_source,requested_start_Beijing='2026-11-09T00:00:00+08:00',end_exclusive_ms=end,results=results,note='官方USDT永续15m数据，不是逐笔；不声称已完成成交引擎回测。15日仅含查询时已收盘部分。');(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps({k:manifest[k]for k in ['server_time_Beijing','results']},ensure_ascii=False,indent=2))
